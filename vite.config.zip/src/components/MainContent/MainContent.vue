<script setup></script>

<template>
<div class="main-container">B</div>
</template>

<style></style>